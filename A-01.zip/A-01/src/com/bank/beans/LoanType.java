package com.bank.beans;

public enum LoanType {
	Home,Car,Education;

}
